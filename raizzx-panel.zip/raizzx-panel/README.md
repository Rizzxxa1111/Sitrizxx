# Raizzx Panel

## Instalar
npm install

## Rodar
npm run dev

## Build
npm run build
